#include<iostream>
#include<fstream>
#include "interface.hpp"

int main(int argc, char* argv[] ) {
	std::ifstream file;
	file.open(argv[1]);

	std::ifstream file2;
	file2.open(argv[2]);
	Comparator c;
	ComparisonReport report = c.compare(file,file2);
	std::cout << report.commonWords.countOfUniqueWords() << " "<<report.uniqueWords[0].countOfUniqueWords() << " " << report.uniqueWords[1].countOfUniqueWords();
	return 0;
}
//Beacause i know how much u value reading a fine book, i used harry potter and the sorcerer's stone <3
//as for the 3rd file i used harry potter and the order of the phoenix