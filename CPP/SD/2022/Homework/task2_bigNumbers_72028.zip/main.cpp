#include "big_numbers_wrapper.cpp"

int main(){

    Wrapper program;
    program.start();
    // std::vector<char> c1 = {'5','5','4','3','4','1'};
    // std::vector<char> c2 = {'1','2','3','4'};


    
    //553107              12456789031415
    //1236123 / 312

    // BigNumber d1(c1,false); // 554341
    // BigNumber d2(c2,false); // 1234
    // d2.to_hexadecimal();

    // int helper = 1234;
    // std::cout << std::hex << helper;
    // BigNumber zero;

    // //DIVSION
    // std::vector<char> h1 = {'1','2','3','6','1','2','3'};
    // std::vector<char> h2 = {'3','1','2'};

    // BigNumber j1(h1,false);
    // BigNumber j2(h2,false);

    // std::pair<BigNumber&, BigNumber&> b5 = j1 / j2;
    // std::cout << b5;

    // //TO DECIMAL
    // std::vector<char> h3 = {'2','a'};
    // BigNumber m1(h3,true);
    // BigNumber m2 = m1.to_decimal();
    // std::cout << m2;
    // std::vector<char> l1 = {'1','2','3','6'};
    // std::vector<char> l2 = {'9','3','6'};

    // BigNumber q1(l1,false);
    // BigNumber q2(l2,false);

    // BigNumber b9 = q1 - q2;
    // std::cout << b9;


    // BigNumber b6 = d1 - d2;
    // std::cout << b6; // 553107

    //MULTIPLICATION
    // std::vector<char> e1 = {'3','1','2'};
    // std::vector<char> e2 = {'9'};
    // BigNumber f1(e1,false);
    // BigNumber f2(e2,false);

    // BigNumber b7 = f1 * f2;
    // std::cout << b7;


    // ADDITION
    // std::vector<char> a1 = {'1','8'};
    // std::vector<char> a2 = {'9','0'};

    // BigNumber b1(a1,false);
    // BigNumber b2(a2,false);

    // BigNumber b5 = b1 + b2;
    // std::cout << b5;

    // std::cout << std::boolalpha << (b5 > b6);
    // std::cout <<  std::boolalpha << (b5 < b6);
    // std::cout <<  std::boolalpha << (b7 == b8);

    // int k = 42;
    // std::cout << std::hex << k;
    
    //1230300151558439221348916026435
    //F87506ED871FC73E5E8405C43
    
    return 0;
}