#include <iostream>
#include <vector>
#include <exception>
#include <algorithm>
#include <fstream>
#include <iomanip>
#include <string>
#pragma once
class BigNumber {
    // TODO: HEX; division;
    private:
    std::vector<char> number;
 
    public:
    BigNumber() {
        this->number.push_back('0');
    }
 
    BigNumber(std::vector<char> num) : number(num) {}
 
    BigNumber(std::string num) {
        std::vector<char> vec;
        for (int i = 0; i < num.size(); i++) {
            vec.push_back(num[i]);
        }
        this->number = vec;
    }
 
    BigNumber& operator=(BigNumber& other_number){
        if(this != &other_number){
            this->number = other_number.get_number();
        } else {
            throw std::bad_alloc();
        }
        return *this;
    }
 
 
    friend std::ostream& operator<<(std::ostream& out, const BigNumber& num);
 
    std::vector<char>& get_number() {
        return this->number;
    }
 
    std::string to_hex() {
        std::string res;
        BigNumber current = *this;
        BigNumber base("16");
        BigNumber zero("0");
 
 
        while (current > zero) {
            std::pair<BigNumber&, BigNumber&> p = current / base;
            current = p.first;
 
            if (p.second.get_number().size() == 1) {
                res.push_back(p.second.get_number()[0]);
            } else {
                switch (p.second.get_number()[1]) {
                case '1':
                    res.push_back('B');
                    break;
                case '2':
                    res.push_back('C');
                    break;
                case '3':
                    res.push_back('D');
                    break;
                case '4':
                    res.push_back('E');
                    break;
                case '5':
                    res.push_back('F');
                    break;
                case '0':
                    res.push_back('A');
                    break;
                default:
                    break;
                }
            }
        }
 
        std::reverse(res.begin(), res.end());
        return res;
    }
 
    bool operator>(BigNumber& other_number) {
        if(this->get_number().size() > other_number.get_number().size()) return true;
        if(this->get_number().size() < other_number.get_number().size()) return false;
        for (size_t i = 0; i < this->get_number().size(); i++)
        {
            if(this->get_number()[i] > other_number.get_number()[i]) return true;
            if(this->get_number()[i] < other_number.get_number()[i]) return false;
        }
        return false;
    }
 
    bool operator<(BigNumber& other_number) {
        if(this->get_number().size() < other_number.get_number().size()) return true;
        if(this->get_number().size() > other_number.get_number().size()) return false;
        for (size_t i = 0; i < this->get_number().size(); i++)
        {
            if(this->get_number()[i] < other_number.get_number()[i]) return true;
            if(this->get_number()[i] > other_number.get_number()[i]) return false;
        }
        return false;
    }
 
    bool operator==(BigNumber& other_number) {
        if(*this < other_number) return false;
        if(*this > other_number) return false;
        return true;
    }
 
    BigNumber& operator+(BigNumber& other_number){
        std::vector<char> helper;
        int i = this->number.size() - 1;
        int j = other_number.get_number().size() - 1;
        int toAdd = 0;
 
        while(i >= 0 || j >= 0) {
            int left = i >= 0 ? this->number[i--] - '0' : 0;
            int right = j >= 0 ? other_number.get_number()[j--] - '0' : 0;
 
            toAdd += left + right;
 
            helper.push_back(toAdd%10 + '0');
            toAdd = toAdd/10;
        }
        if (toAdd != 0) helper.push_back(toAdd + '0');
 
        std::reverse(helper.begin(), helper.end());
 
        BigNumber* toReturn = new BigNumber(helper);
        return *toReturn;
    }
 
    BigNumber& operator-(BigNumber& other_number){
        std::vector<char> helper;
        int i = this->number.size() - 1;
        int j = other_number.number.size() - 1;
        int toAdd = 0;
 
        while(i >= 0 || j >= 0) {
            int left = i >= 0 ? this->number[i--] - '0' + toAdd : 0;
            int right = j >= 0 ? other_number.get_number()[j--] - '0' : 0;
 
            if(left < right) {
                left += 10;
                toAdd = -1;
            } else toAdd = 0;
 
            helper.push_back((left - right) + '0');
        }
 
        for (size_t i = helper.size()-1; i >= 0; i--)
        {
            if (helper[i] == '0') {
                helper.pop_back();
            } else break;
 
        }
 
        std::reverse(helper.begin(), helper.end());
 
 
        BigNumber* toReturn = new BigNumber(helper);
        return *toReturn;
    }
 
    BigNumber& operator*(BigNumber& other_number){
        if(other_number.get_number()[0] == '0' || this->get_number()[0] == '0'){
            return *(new BigNumber());
        }
        int i = this->number.size() - 1;
        int numbers_counter = 0;
        std::vector<BigNumber> bigNums;
 
        while(i >= 0) {
            int left = i >= 0 ? this->number[i--] - '0' : 0;
            std::vector<char> right = other_number.get_number();
 
            int j = other_number.get_number().size() - 1;
            int toAdd = 0;
 
            std::vector<char> helper;
            for (size_t ctr = 0; ctr < numbers_counter; ctr++) {
                helper.push_back(0 + '0');
            }
 
            while(j >= 0){
                toAdd += left * ( right[j--] - '0' );
                helper.push_back(toAdd%10 + '0');
                toAdd = toAdd/10;
            }
 
            if (toAdd != 0) helper.push_back(toAdd + '0');
            std::reverse(helper.begin(), helper.end());
 
            BigNumber newNum(helper);
            bigNums.push_back(newNum);
            numbers_counter++;
        }
 
        BigNumber *toReturn = new BigNumber;
        for (size_t i = 0; i <  bigNums.size(); i++) {
            *toReturn = *toReturn + bigNums[i];
        }
 
        return *toReturn;
    }
 
    
    std::pair<BigNumber&, BigNumber&> operator/(BigNumber& other_number){
        if(this->get_number()[0] == '0') return (std::pair<BigNumber&, BigNumber&>{*(new BigNumber),*(new BigNumber)});
        if(other_number.get_number()[0] == '0')  throw std::overflow_error("Divide by zero exception");

        BigNumber *toReturn = new BigNumber;
        toReturn->get_number().clear();

        BigNumber current;
        current.get_number().clear();
        bool flag = false;
        bool isStart = true;

        for (int i = 0; i < this->get_number().size(); i++) {

            if(current < other_number) {
                current.get_number().push_back(this->get_number()[i]);
                if (flag && !isStart) toReturn->get_number().push_back('0');
                if(current < other_number) {
                    flag = true;
                    continue;
                }
            }
            flag = false;

            for (size_t counter = 1; counter <= 10; counter++) {
                std::vector<char> multiplier_vector;
                multiplier_vector.push_back(counter + '0');
                BigNumber multiplier(multiplier_vector);

                if((other_number * multiplier) > current) {
                    multiplier.get_number()[0] = (counter-1) + '0';

                    current = current - (other_number * multiplier);
                    toReturn->get_number().push_back(counter-1 + '0');
                    isStart = false;
                    break;
                }
            }
        }

        if (toReturn->get_number().size() == 0) toReturn = new BigNumber;
        if (current.get_number().size() == 0) current = *(new BigNumber);

        if (!((*toReturn) * other_number + current == *this)) {
            toReturn->get_number().push_back('0');
        }


        return std::pair<BigNumber&, BigNumber&> {*toReturn, *(new BigNumber(current))};
    }
 
    BigNumber& SQRT(){
        int power = (this->get_number().size())/2;
 
        BigNumber* guess = new BigNumber("1");
        BigNumber ten("10");
        BigNumber two("2");
 
        for (size_t i = 0; i < power; i++) {
            *guess = *guess * ten;
        }
 
        BigNumber curr;
        while (true)
        {
            curr = (((*guess) + ((*this)/(*guess)).first)/two).first;
            if(curr == *guess) break;
            *guess = curr;
        }
 
 
        return *guess;
    }
};
 
std::ostream& operator<<(std::ostream& out, std::pair<BigNumber&, BigNumber&> division) {
    for (size_t i = 0; i < division.first.get_number().size(); i++)
    {
        out << division.first.get_number()[i];
    }
    out << " (";
    for (size_t i = 0; i < division.second.get_number().size(); i++)
    {
        out << division.second.get_number()[i];
    }
    out << ")";
 
    out << '\0';
    return out;
}
 
std::ostream& operator<<(std::ostream& out, const BigNumber& num) {
    for (size_t i = 0; i < num.number.size(); i++)
    {
        out << num.number[i];
    }
    out << '\0';
    return out;
}